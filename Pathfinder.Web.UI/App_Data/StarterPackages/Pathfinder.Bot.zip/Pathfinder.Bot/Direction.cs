﻿namespace Pathfinder.Bot
{
    public enum Direction
    {
        None,
        North,
        South,
        East,
        West
    }
}